#ifndef HEADERCPP_H
#define HEADERCPP_H

#include <iostream>
#include <QApplication>
#include <QVector>
#include <QTableView>
#include "QInputDialog"


using namespace std;

#endif // HEADERCPP_H
